﻿namespace JocelParking
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.parkIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ownerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.parkDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.parkTimeInDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.parkTimeOutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.parkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parkingDataSet3 = new JocelParking.ParkingDataSet3();
            this.btnAdd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.parkingDataSet = new JocelParking.ParkingDataSet();
            this.parkingDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parkingDataSet2 = new JocelParking.ParkingDataSet2();
            this.parkingDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parkTableAdapter = new JocelParking.ParkingDataSet3TableAdapters.parkTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet2BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.parkIDDataGridViewTextBoxColumn,
            this.ownerDataGridViewTextBoxColumn,
            this.contactNoDataGridViewTextBoxColumn,
            this.plateNoDataGridViewTextBoxColumn,
            this.parkDateDataGridViewTextBoxColumn,
            this.parkTimeInDataGridViewTextBoxColumn,
            this.parkTimeOutDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.parkBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(5, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(742, 163);
            this.dataGridView1.TabIndex = 12;
            // 
            // parkIDDataGridViewTextBoxColumn
            // 
            this.parkIDDataGridViewTextBoxColumn.DataPropertyName = "parkID";
            this.parkIDDataGridViewTextBoxColumn.HeaderText = "parkID";
            this.parkIDDataGridViewTextBoxColumn.Name = "parkIDDataGridViewTextBoxColumn";
            // 
            // ownerDataGridViewTextBoxColumn
            // 
            this.ownerDataGridViewTextBoxColumn.DataPropertyName = "owner";
            this.ownerDataGridViewTextBoxColumn.HeaderText = "owner";
            this.ownerDataGridViewTextBoxColumn.Name = "ownerDataGridViewTextBoxColumn";
            // 
            // contactNoDataGridViewTextBoxColumn
            // 
            this.contactNoDataGridViewTextBoxColumn.DataPropertyName = "contactNo";
            this.contactNoDataGridViewTextBoxColumn.HeaderText = "contactNo";
            this.contactNoDataGridViewTextBoxColumn.Name = "contactNoDataGridViewTextBoxColumn";
            // 
            // plateNoDataGridViewTextBoxColumn
            // 
            this.plateNoDataGridViewTextBoxColumn.DataPropertyName = "plateNo";
            this.plateNoDataGridViewTextBoxColumn.HeaderText = "plateNo";
            this.plateNoDataGridViewTextBoxColumn.Name = "plateNoDataGridViewTextBoxColumn";
            // 
            // parkDateDataGridViewTextBoxColumn
            // 
            this.parkDateDataGridViewTextBoxColumn.DataPropertyName = "parkDate";
            this.parkDateDataGridViewTextBoxColumn.HeaderText = "parkDate";
            this.parkDateDataGridViewTextBoxColumn.Name = "parkDateDataGridViewTextBoxColumn";
            // 
            // parkTimeInDataGridViewTextBoxColumn
            // 
            this.parkTimeInDataGridViewTextBoxColumn.DataPropertyName = "parkTimeIn";
            this.parkTimeInDataGridViewTextBoxColumn.HeaderText = "parkTimeIn";
            this.parkTimeInDataGridViewTextBoxColumn.Name = "parkTimeInDataGridViewTextBoxColumn";
            // 
            // parkTimeOutDataGridViewTextBoxColumn
            // 
            this.parkTimeOutDataGridViewTextBoxColumn.DataPropertyName = "parkTimeOut";
            this.parkTimeOutDataGridViewTextBoxColumn.HeaderText = "parkTimeOut";
            this.parkTimeOutDataGridViewTextBoxColumn.Name = "parkTimeOutDataGridViewTextBoxColumn";
            // 
            // parkBindingSource
            // 
            this.parkBindingSource.DataMember = "park";
            this.parkBindingSource.DataSource = this.parkingDataSet3;
            // 
            // parkingDataSet3
            // 
            this.parkingDataSet3.DataSetName = "ParkingDataSet3";
            this.parkingDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(5, 12);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 45);
            this.btnAdd.TabIndex = 13;
            this.btnAdd.Text = "ADD NEW RECORD";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(86, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 45);
            this.button1.TabIndex = 14;
            this.button1.Text = " TIME OUT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // parkingDataSet
            // 
            this.parkingDataSet.DataSetName = "ParkingDataSet";
            this.parkingDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // parkingDataSetBindingSource
            // 
            this.parkingDataSetBindingSource.DataSource = this.parkingDataSet;
            this.parkingDataSetBindingSource.Position = 0;
            // 
            // parkingDataSet2
            // 
            this.parkingDataSet2.DataSetName = "ParkingDataSet2";
            this.parkingDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // parkingDataSet2BindingSource
            // 
            this.parkingDataSet2BindingSource.DataSource = this.parkingDataSet2;
            this.parkingDataSet2BindingSource.Position = 0;
            // 
            // parkTableAdapter
            // 
            this.parkTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(167, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 45);
            this.button2.TabIndex = 15;
            this.button2.Text = " DELETE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(759, 441);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkingDataSet2BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource parkingDataSetBindingSource;
        private ParkingDataSet parkingDataSet;
        private System.Windows.Forms.BindingSource parkingDataSet2BindingSource;
        private ParkingDataSet2 parkingDataSet2;
        private ParkingDataSet3 parkingDataSet3;
        private System.Windows.Forms.BindingSource parkBindingSource;
        private ParkingDataSet3TableAdapters.parkTableAdapter parkTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn parkIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ownerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn parkDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn parkTimeInDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn parkTimeOutDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button2;
    }
}

