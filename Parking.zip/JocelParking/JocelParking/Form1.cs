﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;
namespace JocelParking
{
    public partial class Form1 : Form
    {
        
        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();

        private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\me i\source\repos\JocelParking\JocelParking\Parking.accdb;Persist Security Info=False";
        public Form1()
        {
            bookConn = new OleDbConnection(connParam);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'parkingDataSet3.park' table. You can move, or remove it, as needed.
            this.parkTableAdapter.Fill(this.parkingDataSet3.park);



        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            FormAdd frm = new FormAdd();
            frm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TimeOut frm = new TimeOut();
            frm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                if (!row.IsNewRow) dataGridView1.Rows.Remove(row);
            int selectedCount = dataGridView1.SelectedRows.Count;
            while (selectedCount > 0)
            {
                if (!dataGridView1.SelectedRows[0].IsNewRow)
                    dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                selectedCount--;
            }
        }
    }
}
