﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;
using System.Data.SqlClient;
namespace JocelParking
{
    public partial class TimeOut : Form
    {
        private SqlConnection conn;
        private SqlCommand cmd;
        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();

        private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\me i\source\repos\JocelParking\JocelParking\Parking.accdb;Persist Security Info=False";
        public TimeOut()
        {
    
            bookConn = new OleDbConnection(connParam);
            InitializeComponent();
        }

        private void TimeOut_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'parkingDataSet.park' table. You can move, or remove it, as needed.
            this.parkTableAdapter.Fill(this.parkingDataSet.park);
            // TODO: This line of code loads data into the 'parkingDataSet4.park' table. You can move, or remove it, as needed.
           
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            


        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM park", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UPDATE * FROM park", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1], dataTable.Rows[i][2], dataTable.Rows[i][3], dataTable.Rows[i][4], dataTable.Rows[i][5], dataTable.Rows[i][6]);

            }

            bookConn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                if (!row.IsNewRow) dataGridView1.Rows.Remove(row);
            int selectedCount = dataGridView1.SelectedRows.Count;
            while (selectedCount > 0)
            {
                if (!dataGridView1.SelectedRows[0].IsNewRow)
                    dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                selectedCount--;
            }
        }
    }
}
