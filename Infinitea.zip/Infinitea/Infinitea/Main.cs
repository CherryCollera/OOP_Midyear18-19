﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;

namespace Infinitea
{
    public partial class Main : Form
    {
        private OleDbConnection bookConn;
        private OleDbCommand oleDbcmd = new OleDbCommand();
        public String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=F:\ \Infinitea\Infinitea\OOP.accdb";
        public Main()
        {
            bookConn = new OleDbConnection(connParam);
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {


        }

        private void Main_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'oOPDataSet3.OrderList' table. You can move, or remove it, as needed.
          

            dataGridView1.DataSource = null;


            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }



        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {



        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnMenu_Click(object sender, EventArgs e)
        {

        }

        private void bunifuCustomLabel2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {






        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {




        }

        private void DrinkPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {


        }

        private void button7_Click(object sender, EventArgs e)
        {
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click_1(object sender, EventArgs e)
        {
            Logo.Visible = true;
            DrinkPanel.Visible = false;
            DesertPanel.Visible = false;
            MyCartPanel.Visible = false;
            AboutPanel.Visible = false;
           

        }

        private void bunifuFlatButton3_Click_1(object sender, EventArgs e)
        {
            Logo.Visible = false;

            DrinkPanel.Visible = true;

            DesertPanel.Visible = false;
            MyCartPanel.Visible = false;
            AboutPanel.Visible = false;
            
        }

        private void bunifuFlatButton4_Click_1(object sender, EventArgs e)
        {
            Logo.Visible = false;
            DrinkPanel.Visible = false;
            DesertPanel.Visible = true;
            MyCartPanel.Visible = false;
            AboutPanel.Visible = false;
    
        }

        private void bunifuFlatButton5_Click_1(object sender, EventArgs e)
        {
            Logo.Visible = false;
            DrinkPanel.Visible = false;
            DesertPanel.Visible = false;
            MyCartPanel.Visible = true;
            AboutPanel.Visible = false;
            
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            Logo.Visible = false;
            DrinkPanel.Visible = false;
            DesertPanel.Visible = false;
            MyCartPanel.Visible = false;
            AboutPanel.Visible = true;
         
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewCell cell = null;

            foreach
                (DataGridViewCell selectedCell in dataGridView1.SelectedCells)
            {
                cell = selectedCell;
                break;

            }
            if (cell != null)
            {
                DataGridViewRow row = cell.OwningRow;
                bunifuTextbox2.text = row.Cells[1].Value.ToString();
              

            }
        }

        private void bunifuCustomLabel21_Click(object sender, EventArgs e)
        {

        }

        private void bunifuCustomLabel11_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            int wine = 100;
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "wine" + "', '" + wine + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }

        }

        private void bunifuCustomLabel8_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTextbox1_OnTextChange(object sender, EventArgs e)
        {

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value);
            }
            bunifuTextbox1.text = sum.ToString();

        }

        private void btnMenu_Click_1(object sender, EventArgs e)
        {
            if (panel1.Width == 50)
            {

                panel1.Visible = false;
                panel1.Width = 260;
                PanelTransition.ShowSync(panel1);
                LogoTransition.ShowSync(Logo);

            }
            else
            {
                LogoTransition.Hide(Logo);
                panel1.Visible = false;
                panel1.Width = 50;
                PanelTransition.ShowSync(panel1);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Shakes" + "', '" + 75 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Cola" + "', '" + 60 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Fruit Juice" + "', '" + 35 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Coffee" + "', '" + 50 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Shawarma" + "', '" + 150 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {

        }

        private void bunifuCustomLabel6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Hotdog" + "', '" + 85 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "pizza" + "', '" + 220 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Fries" + "', '" + 160 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Tacos" + "', '" + 140 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Paella" + "', '" + 260 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet(); 

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void bunifuCustomLabel18_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Banana Split" + "', '" + 175 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Chocolates" + "', '" + 75 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart" ,"Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Cupcake" + "', '" + 25 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart" ,"Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Jelly" + "', '" + 60 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;

            oleDbcmd.CommandText = "insert into OrderList (Item, Price) values ('" + "Ice Cream" + "', '" + 45 + "');";
            int temp = oleDbcmd.ExecuteNonQuery();

            MessageBox.Show("Order Successfully Added To Cart", "Order Succesful");


            bookConn.Close();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void bunifuFlatButton6_Click_1(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbcmd.Connection = bookConn;
            oleDbcmd.CommandText = "delete from OrderList where Item ='" + bunifuTextbox2.text + "'";
            oleDbcmd.ExecuteNonQuery();
            bookConn.Close();
            MessageBox.Show("Order Succesfully Deleted");

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM OrderList", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("Update * FROM OrderList", connParam);

            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                dataTable.Rows[i][1], dataTable.Rows[i][2]);
            }
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
          
            Logo.Visible = false;
            DrinkPanel.Visible = false;
            DesertPanel.Visible = false;
            MyCartPanel.Visible = false;
            AboutPanel.Visible = false;
        }
    }
}
