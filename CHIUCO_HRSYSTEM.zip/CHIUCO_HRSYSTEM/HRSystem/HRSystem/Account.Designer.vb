﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Account
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Account))
        Me.btnadd = New System.Windows.Forms.Button()
        Me.btnedd = New System.Windows.Forms.Button()
        Me.btndel = New System.Windows.Forms.Button()
        Me.GtblBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.HoteldbDataSet1 = New HRSystem.HoteldbDataSet1()
        Me.HoteldbDataSet = New HRSystem.HoteldbDataSet()
        Me.GtblBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GtblTableAdapter = New HRSystem.HoteldbDataSetTableAdapters.gtblTableAdapter()
        Me.GtblTableAdapter1 = New HRSystem.HoteldbDataSet1TableAdapters.gtblTableAdapter()
        Me.btnout = New System.Windows.Forms.Button()
        Me.Realguestbl = New HRSystem.realguestbl()
        Me.GuesttblBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GuesttblTableAdapter = New HRSystem.realguestblTableAdapters.guesttblTableAdapter()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GuestID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Fname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Lname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Age = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Contact = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Room = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GuesttblBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.HoteldbDataSet2 = New HRSystem.HoteldbDataSet2()
        Me.GuesttblTableAdapter1 = New HRSystem.HoteldbDataSet2TableAdapters.guesttblTableAdapter()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.txtsrch = New System.Windows.Forms.TextBox()
        Me.btnref = New System.Windows.Forms.Button()
        CType(Me.GtblBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HoteldbDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HoteldbDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GtblBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Realguestbl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GuesttblBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GuesttblBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HoteldbDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(162, 293)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(88, 32)
        Me.btnadd.TabIndex = 4
        Me.btnadd.Text = "Add Guest"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'btnedd
        '
        Me.btnedd.Location = New System.Drawing.Point(162, 331)
        Me.btnedd.Name = "btnedd"
        Me.btnedd.Size = New System.Drawing.Size(88, 31)
        Me.btnedd.TabIndex = 5
        Me.btnedd.Text = "Update Info"
        Me.btnedd.UseVisualStyleBackColor = True
        '
        'btndel
        '
        Me.btndel.Location = New System.Drawing.Point(451, 330)
        Me.btndel.Name = "btndel"
        Me.btndel.Size = New System.Drawing.Size(88, 32)
        Me.btndel.TabIndex = 6
        Me.btndel.Text = "Delete"
        Me.btndel.UseVisualStyleBackColor = True
        '
        'GtblBindingSource1
        '
        Me.GtblBindingSource1.DataMember = "gtbl"
        Me.GtblBindingSource1.DataSource = Me.HoteldbDataSet1
        '
        'HoteldbDataSet1
        '
        Me.HoteldbDataSet1.DataSetName = "HoteldbDataSet1"
        Me.HoteldbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'HoteldbDataSet
        '
        Me.HoteldbDataSet.DataSetName = "HoteldbDataSet"
        Me.HoteldbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GtblBindingSource
        '
        Me.GtblBindingSource.DataMember = "gtbl"
        Me.GtblBindingSource.DataSource = Me.HoteldbDataSet
        '
        'GtblTableAdapter
        '
        Me.GtblTableAdapter.ClearBeforeFill = True
        '
        'GtblTableAdapter1
        '
        Me.GtblTableAdapter1.ClearBeforeFill = True
        '
        'btnout
        '
        Me.btnout.Location = New System.Drawing.Point(451, 293)
        Me.btnout.Name = "btnout"
        Me.btnout.Size = New System.Drawing.Size(88, 32)
        Me.btnout.TabIndex = 7
        Me.btnout.Text = "Log Out"
        Me.btnout.UseVisualStyleBackColor = True
        '
        'Realguestbl
        '
        Me.Realguestbl.DataSetName = "realguestbl"
        Me.Realguestbl.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GuesttblBindingSource
        '
        Me.GuesttblBindingSource.DataMember = "guesttbl"
        Me.GuesttblBindingSource.DataSource = Me.Realguestbl
        '
        'GuesttblTableAdapter
        '
        Me.GuesttblTableAdapter.ClearBeforeFill = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveBorder
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.GuestID, Me.Fname, Me.Lname, Me.Age, Me.Contact, Me.Email, Me.Room})
        Me.DataGridView1.DataSource = Me.GuesttblBindingSource1
        Me.DataGridView1.Location = New System.Drawing.Point(13, 54)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(740, 233)
        Me.DataGridView1.TabIndex = 8
        '
        'GuestID
        '
        Me.GuestID.DataPropertyName = "Guest_ID"
        Me.GuestID.HeaderText = "Guest ID"
        Me.GuestID.Name = "GuestID"
        Me.GuestID.ReadOnly = True
        '
        'Fname
        '
        Me.Fname.DataPropertyName = "fname"
        Me.Fname.HeaderText = "First Name"
        Me.Fname.Name = "Fname"
        Me.Fname.ReadOnly = True
        '
        'Lname
        '
        Me.Lname.DataPropertyName = "lname"
        Me.Lname.HeaderText = "Last Name"
        Me.Lname.Name = "Lname"
        Me.Lname.ReadOnly = True
        '
        'Age
        '
        Me.Age.DataPropertyName = "age"
        Me.Age.HeaderText = "Age"
        Me.Age.Name = "Age"
        Me.Age.ReadOnly = True
        '
        'Contact
        '
        Me.Contact.DataPropertyName = "contact"
        Me.Contact.HeaderText = "Contact Number"
        Me.Contact.Name = "Contact"
        Me.Contact.ReadOnly = True
        '
        'Email
        '
        Me.Email.DataPropertyName = "email"
        Me.Email.HeaderText = "E-mail"
        Me.Email.Name = "Email"
        Me.Email.ReadOnly = True
        '
        'Room
        '
        Me.Room.DataPropertyName = "room"
        Me.Room.HeaderText = "Room Number"
        Me.Room.Name = "Room"
        Me.Room.ReadOnly = True
        '
        'GuesttblBindingSource1
        '
        Me.GuesttblBindingSource1.DataMember = "guesttbl"
        Me.GuesttblBindingSource1.DataSource = Me.HoteldbDataSet2
        '
        'HoteldbDataSet2
        '
        Me.HoteldbDataSet2.DataSetName = "HoteldbDataSet2"
        Me.HoteldbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GuesttblTableAdapter1
        '
        Me.GuesttblTableAdapter1.ClearBeforeFill = True
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(451, 12)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(88, 32)
        Me.btnsearch.TabIndex = 2
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'txtsrch
        '
        Me.txtsrch.Location = New System.Drawing.Point(206, 19)
        Me.txtsrch.Name = "txtsrch"
        Me.txtsrch.Size = New System.Drawing.Size(239, 20)
        Me.txtsrch.TabIndex = 1
        '
        'btnref
        '
        Me.btnref.Location = New System.Drawing.Point(593, 12)
        Me.btnref.Name = "btnref"
        Me.btnref.Size = New System.Drawing.Size(88, 32)
        Me.btnref.TabIndex = 3
        Me.btnref.Text = "Refresh"
        Me.btnref.UseVisualStyleBackColor = True
        '
        'Account
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.BackgroundImage = Global.HRSystem.My.Resources.Resources.hotel
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(765, 386)
        Me.Controls.Add(Me.btnref)
        Me.Controls.Add(Me.txtsrch)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnout)
        Me.Controls.Add(Me.btndel)
        Me.Controls.Add(Me.btnedd)
        Me.Controls.Add(Me.btnadd)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Account"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Guest List"
        CType(Me.GtblBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HoteldbDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HoteldbDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GtblBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Realguestbl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GuesttblBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GuesttblBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HoteldbDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents btnedd As System.Windows.Forms.Button
    Friend WithEvents btndel As System.Windows.Forms.Button
    Friend WithEvents HoteldbDataSet As HRSystem.HoteldbDataSet
    Friend WithEvents GtblBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GtblTableAdapter As HRSystem.HoteldbDataSetTableAdapters.gtblTableAdapter
    Friend WithEvents HoteldbDataSet1 As HRSystem.HoteldbDataSet1
    Friend WithEvents GtblBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents GtblTableAdapter1 As HRSystem.HoteldbDataSet1TableAdapters.gtblTableAdapter
    Friend WithEvents GGuestIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnout As System.Windows.Forms.Button
    Friend WithEvents Realguestbl As HRSystem.realguestbl
    Friend WithEvents GuesttblBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GuesttblTableAdapter As HRSystem.realguestblTableAdapters.guesttblTableAdapter
    Friend WithEvents HoteldbDataSet2 As HRSystem.HoteldbDataSet2
    Friend WithEvents GuesttblBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents GuesttblTableAdapter1 As HRSystem.HoteldbDataSet2TableAdapters.guesttblTableAdapter
    Friend WithEvents GuestID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Fname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Age As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Contact As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Email As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Room As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents txtsrch As System.Windows.Forms.TextBox
    Friend WithEvents btnref As System.Windows.Forms.Button
End Class
