﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Dlt
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
    Public dr As SqlDataReader
    Dim objdv As New DataView
    Dim con As New SqlConnection("Data Source=BEE-PC;Initial Catalog=Hoteldb;Integrated Security=True")
    Dim cmd As New SqlCommand
    Private Sub btndell_Click(sender As Object, e As EventArgs) Handles btndell.Click
        con.Open()
        Dim cmddel As New SqlCommand
        Try
            cmddel = New SqlCommand("DELETE FROM guesttbl WHERE Guest_ID like '" & txtgid.Text & "'", con)
            dr = cmddel.ExecuteReader
            MsgBox("Record Deleted")


            Account.gridviewrefresh()
            Account.DataGridView1.Update()
            txtgid.Clear()
            con.Close()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub

    Private Sub Dlt_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btncance_Click(sender As Object, e As EventArgs) Handles btncance.Click
        Me.Hide()
    End Sub
End Class