﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Addguest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Addguest))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtroom = New System.Windows.Forms.TextBox()
        Me.txtema = New System.Windows.Forms.TextBox()
        Me.txtcont = New System.Windows.Forms.TextBox()
        Me.txtag = New System.Windows.Forms.TextBox()
        Me.txtln = New System.Windows.Forms.TextBox()
        Me.txtfn = New System.Windows.Forms.TextBox()
        Me.btnres = New System.Windows.Forms.Button()
        Me.btncan = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(63, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Name: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(62, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Last Name: "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(94, 95)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Age: "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(36, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Contact Number: "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(88, 153)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Email: "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(45, 182)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Room Number: "
        '
        'txtroom
        '
        Me.txtroom.Location = New System.Drawing.Point(133, 182)
        Me.txtroom.Name = "txtroom"
        Me.txtroom.Size = New System.Drawing.Size(100, 20)
        Me.txtroom.TabIndex = 11
        '
        'txtema
        '
        Me.txtema.Location = New System.Drawing.Point(133, 150)
        Me.txtema.Name = "txtema"
        Me.txtema.Size = New System.Drawing.Size(100, 20)
        Me.txtema.TabIndex = 10
        '
        'txtcont
        '
        Me.txtcont.Location = New System.Drawing.Point(133, 123)
        Me.txtcont.Name = "txtcont"
        Me.txtcont.Size = New System.Drawing.Size(100, 20)
        Me.txtcont.TabIndex = 9
        '
        'txtag
        '
        Me.txtag.Location = New System.Drawing.Point(133, 92)
        Me.txtag.Name = "txtag"
        Me.txtag.Size = New System.Drawing.Size(100, 20)
        Me.txtag.TabIndex = 8
        '
        'txtln
        '
        Me.txtln.Location = New System.Drawing.Point(133, 65)
        Me.txtln.Name = "txtln"
        Me.txtln.Size = New System.Drawing.Size(100, 20)
        Me.txtln.TabIndex = 7
        '
        'txtfn
        '
        Me.txtfn.Location = New System.Drawing.Point(132, 39)
        Me.txtfn.Name = "txtfn"
        Me.txtfn.Size = New System.Drawing.Size(100, 20)
        Me.txtfn.TabIndex = 6
        '
        'btnres
        '
        Me.btnres.Location = New System.Drawing.Point(24, 256)
        Me.btnres.Name = "btnres"
        Me.btnres.Size = New System.Drawing.Size(87, 37)
        Me.btnres.TabIndex = 12
        Me.btnres.Text = "Reserve"
        Me.btnres.UseVisualStyleBackColor = True
        '
        'btncan
        '
        Me.btncan.Location = New System.Drawing.Point(197, 256)
        Me.btncan.Name = "btncan"
        Me.btncan.Size = New System.Drawing.Size(87, 37)
        Me.btncan.TabIndex = 13
        Me.btncan.Text = "Cancel"
        Me.btncan.UseVisualStyleBackColor = True
        '
        'Addguest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(325, 338)
        Me.Controls.Add(Me.btncan)
        Me.Controls.Add(Me.btnres)
        Me.Controls.Add(Me.txtfn)
        Me.Controls.Add(Me.txtln)
        Me.Controls.Add(Me.txtag)
        Me.Controls.Add(Me.txtcont)
        Me.Controls.Add(Me.txtema)
        Me.Controls.Add(Me.txtroom)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Addguest"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Guest Reservation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtroom As System.Windows.Forms.TextBox
    Friend WithEvents txtema As System.Windows.Forms.TextBox
    Friend WithEvents txtcont As System.Windows.Forms.TextBox
    Friend WithEvents txtag As System.Windows.Forms.TextBox
    Friend WithEvents txtln As System.Windows.Forms.TextBox
    Friend WithEvents txtfn As System.Windows.Forms.TextBox
    Friend WithEvents btnres As System.Windows.Forms.Button
    Friend WithEvents btncan As System.Windows.Forms.Button
End Class
