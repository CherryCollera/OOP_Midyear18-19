﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Register
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Register))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtuserr = New System.Windows.Forms.TextBox()
        Me.txtpasss = New System.Windows.Forms.TextBox()
        Me.btnreg = New System.Windows.Forms.Button()
        Me.btncan = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtcon = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtem = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtlname = New System.Windows.Forms.TextBox()
        Me.txtfname = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(62, 131)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Username:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(64, 157)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Password:"
        '
        'txtuserr
        '
        Me.txtuserr.Location = New System.Drawing.Point(128, 124)
        Me.txtuserr.Name = "txtuserr"
        Me.txtuserr.Size = New System.Drawing.Size(100, 20)
        Me.txtuserr.TabIndex = 4
        '
        'txtpasss
        '
        Me.txtpasss.Location = New System.Drawing.Point(128, 150)
        Me.txtpasss.Name = "txtpasss"
        Me.txtpasss.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtpasss.Size = New System.Drawing.Size(100, 20)
        Me.txtpasss.TabIndex = 5
        '
        'btnreg
        '
        Me.btnreg.Location = New System.Drawing.Point(45, 251)
        Me.btnreg.Name = "btnreg"
        Me.btnreg.Size = New System.Drawing.Size(75, 23)
        Me.btnreg.TabIndex = 8
        Me.btnreg.Text = "Register"
        Me.btnreg.UseVisualStyleBackColor = True
        '
        'btncan
        '
        Me.btncan.Location = New System.Drawing.Point(177, 251)
        Me.btncan.Name = "btncan"
        Me.btncan.Size = New System.Drawing.Size(75, 23)
        Me.btncan.TabIndex = 9
        Me.btncan.Text = "Cancel"
        Me.btncan.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(53, 183)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Contact No.:"
        '
        'txtcon
        '
        Me.txtcon.Location = New System.Drawing.Point(128, 176)
        Me.txtcon.Name = "txtcon"
        Me.txtcon.Size = New System.Drawing.Size(100, 20)
        Me.txtcon.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(79, 206)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "E-mail: "
        '
        'txtem
        '
        Me.txtem.Location = New System.Drawing.Point(128, 203)
        Me.txtem.Name = "txtem"
        Me.txtem.Size = New System.Drawing.Size(100, 20)
        Me.txtem.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(64, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "First Name: "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(62, 102)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Last Name: "
        '
        'txtlname
        '
        Me.txtlname.Location = New System.Drawing.Point(128, 98)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(100, 20)
        Me.txtlname.TabIndex = 3
        '
        'txtfname
        '
        Me.txtfname.Location = New System.Drawing.Point(128, 72)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(100, 20)
        Me.txtfname.TabIndex = 2
        '
        'Register
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 325)
        Me.Controls.Add(Me.txtfname)
        Me.Controls.Add(Me.txtlname)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtem)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtcon)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btncan)
        Me.Controls.Add(Me.btnreg)
        Me.Controls.Add(Me.txtpasss)
        Me.Controls.Add(Me.txtuserr)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Register"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Employee Registration"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtuserr As System.Windows.Forms.TextBox
    Friend WithEvents txtpasss As System.Windows.Forms.TextBox
    Friend WithEvents btnreg As System.Windows.Forms.Button
    Friend WithEvents btncan As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtcon As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtem As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents txtfname As System.Windows.Forms.TextBox
End Class
