﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Addguest
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
    Public dr As SqlDataReader
    Dim objdv As New DataView
    Dim con As New SqlConnection("Data Source=BEE-PC;Initial Catalog=Hoteldb;Integrated Security=True")
    Dim cmd As New SqlCommand
    Private Sub btncan_Click(sender As Object, e As EventArgs) Handles btncan.Click
        Me.Hide()

    End Sub
    Private Sub gridviewrefresh()
        Try
            Dim cmd As SqlCommand

            cmd = New SqlCommand("select * from guesttbl", con)
            Dim da As SqlDataAdapter
            Dim ds As New DataSet

            da = New SqlDataAdapter(cmd)
            ds = New DataSet

            da.Fill(ds, "guesttbl")

            con.Open()
            objdv = ds.Tables(0).DefaultView
            Account.DataGridView1.DataSource = objdv
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Account.DataGridView1.Refresh()
    End Sub

    Private Sub btnres_Click(sender As Object, e As EventArgs) Handles btnres.Click
        con.Open()
        Using cmdsave As New SqlClient.SqlCommand("INSERT INTO guesttbl(fname,lname,age,contact,email,room) values('" & txtfn.Text & "','" & txtln.Text & "','" & txtag.Text & "','" & txtcont.Text & "', '" & txtema.Text & "','" & txtroom.Text & "')", con)
            cmdsave.ExecuteNonQuery()
        End Using
        MsgBox("Guest Reserved!")

        con.Close()
        Account.gridviewrefresh()
        Me.Close()

    End Sub

    Private Sub Addguest_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class