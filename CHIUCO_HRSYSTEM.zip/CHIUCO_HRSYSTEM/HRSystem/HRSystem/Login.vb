﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Login
    Dim con As New SqlConnection("Data Source=BEE-PC;Initial Catalog=Hoteldb;Integrated Security=True")
    Private _version As String

    Private Property Version(p1 As String) As String
        Get
            Return _version
        End Get
        Set(value As String)
            _version = value
        End Set
    End Property

    Private Sub btnlog_Click(sender As Object, e As EventArgs) Handles btnlog.Click
        Dim cmd As New SqlCommand
        Dim rd As SqlDataReader

        cmd.Connection = con
        con.Open()
            cmd.CommandText = "SELECT uname, upass FROM Rectbl WHERE uname = '" & txtuser.Text & "' and upass = '" & txtpass.Text & "'"
            rd = cmd.ExecuteReader
            If rd.HasRows And rd.Read = True Then
                Version("wtf") = txtuser.Text
                Version("gggg") = txtpass.Text
            Account.Show()
            Me.Hide()
            Else
                MsgBox("Invalid Username or Password", MsgBoxStyle.Exclamation)
            Me.Focus()

        End If
        txtuser.Clear()
        txtpass.Clear()
        con.Close()
    End Sub

    Private Sub btnreg_Click(sender As Object, e As EventArgs) Handles btnreg.Click
        Register.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtpass_TextChanged(sender As Object, e As EventArgs) Handles txtpass.TextChanged

    End Sub
End Class
