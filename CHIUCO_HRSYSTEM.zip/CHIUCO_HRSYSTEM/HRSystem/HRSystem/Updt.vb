﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Updt
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
    Public dr As SqlDataReader
    Dim objdv As New DataView
    Dim con As New SqlConnection("Data Source=BEE-PC;Initial Catalog=Hoteldb;Integrated Security=True")
    Dim cmd As New SqlCommand
    Private Sub btncanc_Click(sender As Object, e As EventArgs) Handles btncanc.Click
        Me.Hide()
    End Sub
    Private Sub btnup_Click(sender As Object, e As EventArgs) Handles btnup.Click
        Using connection As New SqlConnection("Data Source=BEE-PC;Initial Catalog=Hoteldb;Integrated Security=True")
            Dim updt As String = "UPDATE guesttbl set fname = @fname, lname = @lname, age = @age, contact = @contact, email = @email, room = @room WHERE [Guest_ID] = @Guest_ID"
            Try
                Using cmdupdate As New SqlCommand(updt, con)
                    con.Open()
                    cmdupdate.Parameters.AddWithValue("Guest_ID", SqlDbType.VarChar).Value = txtid.Text
                    cmdupdate.Parameters.AddWithValue("fname", SqlDbType.VarChar).Value = txtfnm.Text
                    cmdupdate.Parameters.AddWithValue("lname", SqlDbType.VarChar).Value = txtlnm.Text
                    cmdupdate.Parameters.AddWithValue("age", SqlDbType.VarChar).Value = txtagg.Text
                    cmdupdate.Parameters.AddWithValue("contact", SqlDbType.VarChar).Value = txtcontc.Text
                    cmdupdate.Parameters.AddWithValue("email", SqlDbType.NVarChar).Value = txtemai.Text
                    cmdupdate.Parameters.AddWithValue("room", SqlDbType.VarChar).Value = txtroomn.Text
                    cmdupdate.ExecuteNonQuery()

                    MsgBox("Information Updated!")

                    'Account.DataGridView1.Refresh()
                    'Account.Refresh()
                    Account.gridviewrefresh()
                End Using
                txtagg.Clear()
                txtcontc.Clear()
                txtemai.Clear()
                txtfnm.Clear()
                txtid.Clear()
                txtroomn.Clear()
                txtlnm.Clear()

                con.Close()
                Account.Show()
                Me.Hide()
            Catch ex As Exception
                MsgBox("There's an error on updating")
            End Try
        End Using
    End Sub

    Private Sub Updt_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class