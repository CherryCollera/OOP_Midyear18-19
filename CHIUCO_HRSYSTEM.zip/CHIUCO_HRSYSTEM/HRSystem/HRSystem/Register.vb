﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Register
    Dim con As New SqlConnection("Data Source=BEE-PC;Initial Catalog=Hoteldb;Integrated Security=True")
    Dim cmd As New SqlCommand
    Private Sub btncan_Click(sender As Object, e As EventArgs) Handles btncan.Click
        Login.Show()
        Me.Close()

    End Sub

    Private Sub btn2_TextChanged(sender As Object, e As EventArgs) Handles txtpasss.TextChanged

    End Sub

    Private Sub btnreg_Click(sender As Object, e As EventArgs) Handles btnreg.Click
        con.Open()
        Using cmdsave As New SqlClient.SqlCommand("INSERT INTO Rectbl(ufname,ulname,uname,upass,unum,uemail) values('" & txtfname.Text & "','" & txtlname.Text & "','" & txtuserr.Text & "','" & txtpasss.Text & "', '" & txtcon.Text & "','" & txtem.Text & "')", con)
            cmdsave.ExecuteNonQuery()
        End Using
        MsgBox("You are now Registered!")
        txtuserr.Clear()
        txtpasss.Clear()
        txtfname.Clear()
        txtlname.Clear()
        txtcon.Clear()
        txtem.Clear()

        con.Close()
        Me.Close()
        Login.Show()

    End Sub

    Private Sub Register_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class