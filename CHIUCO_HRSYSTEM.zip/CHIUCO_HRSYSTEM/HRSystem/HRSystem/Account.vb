﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Account
    'Dim da As New SqlDataAdapter
    Dim ds As New DataSet
    Public dr As SqlDataReader
    Dim objdv As New DataView
    Dim con As New SqlConnection("Data Source=BEE-PC;Initial Catalog=Hoteldb;Integrated Security=True")
    'Dim cmd As New SqlCommand
    Private Sub Account_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HoteldbDataSet2.guesttbl' table. You can move, or remove it, as needed.
        Me.GuesttblTableAdapter1.Fill(Me.HoteldbDataSet2.guesttbl)
        'TODO: This line of code loads data into the 'Realguestbl.guesttbl' table. You can move, or remove it, as needed.
        Me.GuesttblTableAdapter.Fill(Me.Realguestbl.guesttbl)

        FilterData("")

    End Sub
    Public Sub FilterData(valueToSearch As String)

        Dim sq As String = "SELECT * from guesttbl WHERE CONCAT(Guest_ID,fname, lname, room) like '%" & valueToSearch & "%'"





        Dim cmd As New SqlCommand(sq, con)
        Dim da As New SqlDataAdapter(cmd)
        Dim tbl As New DataTable()


        da.Fill(tbl)
        DataGridView1.DataSource = tbl

    End Sub
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Addguest.Show()
    End Sub

    Private Sub btnout_Click(sender As Object, e As EventArgs) Handles btnout.Click
        Login.Show()
        Me.Hide()
    End Sub
    Public Sub gridviewrefresh()
        Try
            Dim cmd As SqlCommand

            cmd = New SqlCommand("select * from guesttbl", con)
            Dim da As SqlDataAdapter
            Dim ds As New DataSet

            da = New SqlDataAdapter(cmd)
            ds = New DataSet

            da.Fill(ds, "guesttbl")

            con.Open()
            objdv = ds.Tables(0).DefaultView
            Me.DataGridView1.DataSource = objdv
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnedd_Click(sender As Object, e As EventArgs) Handles btnedd.Click
        Updt.Show()
    End Sub

    Private Sub btndel_Click(sender As Object, e As EventArgs) Handles btndel.Click
        Dlt.Show()
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        FilterData(txtsrch.Text)
    End Sub

    Private Sub btnref_Click(sender As Object, e As EventArgs) Handles btnref.Click
        txtsrch.Clear()
        Me.gridviewrefresh()
    End Sub
End Class