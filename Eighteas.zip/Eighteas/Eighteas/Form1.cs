﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;

namespace Eighteas
{
    public partial class Form1 : Form
    {
        private OleDbConnection conn;
        private OleDbCommand oleDbCmd = new OleDbCommand();

        private String connParam = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = C:\Users\me i\source\repos\Eighteas\Eighteas\inventory.accdb;Persist Security Info=False";
        public Form1()
        {
            conn = new OleDbConnection(connParam);
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'inventoryDataSet.eighteas' table. You can move, or remove it, as needed.
            this.eighteasTableAdapter.Fill(this.inventoryDataSet.eighteas);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                if (!row.IsNewRow) dataGridView1.Rows.Remove(row);
            int selectedCount = dataGridView1.SelectedRows.Count;
            while (selectedCount > 0)
            {
                if (!dataGridView1.SelectedRows[0].IsNewRow)
                    dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                selectedCount--;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            oleDbCmd.Connection = conn;
            oleDbCmd.CommandText = "INSERT INTO eighteas (productID, orderDate,productName, productPrice) values ('" + this.textBox3.Text + "','" + this.dateTimePicker1.MaxDate + "','" + this.textBox1.Text + "','" + this.textBox2.Text + "')";
            int temp = oleDbCmd.ExecuteNonQuery();

            if (temp > 0)
            {
                textBox3.Text = null;
                textBox1.Text = null;
                textBox2.Text = null;

               dateTimePicker1.Format = DateTimePickerFormat.Custom;
                dateTimePicker1.CustomFormat = "dd-MM-yyyy";




                MessageBox.Show("Record Successfuly Added!");
            }
            else
            {
                MessageBox.Show("Record Fail to Added!");

            }
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM eighteas", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UPDATE * FROM eighteas", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1], dataTable.Rows[i][2], dataTable.Rows[i][3]);

            }

            conn.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
           Inventory frm = new Inventory();
            frm.Show();
            this.Hide();
        }
    }
}
