﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OleDb;


namespace Eighteas
{
    public partial class Inventory : Form
    {
        private OleDbConnection conn;
        private String connParam = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = C:\Users\me i\source\repos\Eighteas\Eighteas\inventory.accdb;Persist Security Info=False";
        OleDbCommand cmd;
        OleDbDataAdapter da;
        DataTable dt;
        string sql;
        public Inventory()
        {
            conn = new OleDbConnection(connParam);

            InitializeComponent();
            
        }
        

        private void Inventory_Load(object sender, EventArgs e)
        {
            sql = "select plateNo, u_name as productName, u_type as UserRole, DateJoined From eighteas WHERE DateJoined >= #" + dateTimePicker1.Value.ToString("dd/MM/yyyy") + "# and Datejoined >= #" + dateTimePicker2.Value.ToString("dd/MM/yyyy") + "#";
            find_data(sql, dataGridView1);
            
            // TODO: This line of code loads data into the 'inventoryDataSet1.eighteas' table. You can move, or remove it, as needed.
            this.eighteasTableAdapter.Fill(this.inventoryDataSet1.eighteas);

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            sql = "select plateNo, u_name as productName, u_type as UserRole, DateJoined From eighteas WHERE DateJoined >= #" + dateTimePicker1.Value.ToString("dd/MM/yyyy") + "# and Datejoined >= #" + dateTimePicker2.Value.ToString("dd/MM/yyyy") + "#";
            find_data(sql, dataGridView1);
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            sql = "select plateNo, u_name as productName, u_type as UserRole, DateJoined From eighteas WHERE DateJoined >= #" + dateTimePicker1.Value.ToString("dd/MM/yyyy") + "# and Datejoined >= #" + dateTimePicker2.Value.ToString("dd/MM/yyyy") + "#";
            find_data(sql, dataGridView1);
        }
        private void find_data(string sql, DataGridView dtg)
        {
            try
            {
                conn.Open();
                cmd = new OleDbCommand();
                da = new OleDbDataAdapter();
                dt = new DataTable();

                cmd.Connection = conn;
                cmd.CommandText = sql;

                da.SelectCommand = cmd;
                da.Fill(dt);

                dtg.DataSource = dt;
                dtg.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);


            }
            finally
            {
                da.Dispose();
                conn.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }
    }
}
